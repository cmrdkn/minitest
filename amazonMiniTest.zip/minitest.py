# -*- coding : UTF-8 -*-
import datetime, time
import selenium
import os
from selenium.common.exceptions import NoSuchFrameException
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException
from selenium.common.exceptions import ElementNotVisibleException
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import NoSuchWindowException



class minitest_tool():
    link = "https://www.amazon.com"
    driver = "Chrome" # veya Firefox
    __email = "cemardaakin@yandex.com"
    __password = "insiderTest_06022018"
    logfileName = "log.tsv"
    __logfile = open(str(logfileName), "w")
    _browser = None
    TargetProduct = None
    TargetProductASIN = None

    def __init__(self):

        print("""
        # ##########################################################\n
        # login için kayıtlı bilgileri kullanabilirsiniz, test amaçlı açtığım bir hesaptır
        # geckoDriver ve ChromeDriver drivers klasöründedir\n
        # Screenshots klasöründe ekran görüntüleri yer alır\n
        # işlem sonunda log.tsv dosyasında logları bulabilirsiniz\n
        # Kötü bağlantım sebebiyle time.sleep beklemeleri koymak durumunda kaldım,
          adımlar arasında zaman zaman beklemeniz gerekebilir, sonlandığında console üzerinden bunu belirtir\n
        # windows ortamı için Python3.6.3 ve selenium 3.8.1 ile chromedriver ve geckodriver için hazirlanmistir.  
        # Cem Arda Akın\n
        # ##########################################################
        """)


        if self.start() is True:
            self._browser.get(self.link)
            self.scenario()
        else:
            print("errorrr")

    def scenario(self):
        if self.hover("//a[@id='nav-link-accountList']", "a#nav-link-accountList") is False: return False
        if self.screenshot("Step1-ilkadim") is False: return False
        if self.click("//span[@class='nav-action-inner']", "span.nav-action-inner") is False: return False
        if self.login(1, 1, 0) is False: return False
        if self.screenshot("Step2-loginekrani") is False: return False
        if self.searchItem("SAMSUNG", 0) is False: return False
        if self.screenshot("Step3-aramasonunda") is False: return False
        if self.results() is False: return False
        if self.screenshot("Step4-aramasonuclari") is False: return False
        if self.scroll("//div[@id='bottomBar']") is False: return False
        if self.changePage(2) is False: return False
        if self.pageControl(2) is False: return False
        if self.screenshot("Step5-sayfa2") is False: return False
        if self.productsOnpage(3, "//ul[@id='s-results-list-atf']","//ul[@id='s-results-list-atf']/li") is False: return False
        if self.screenshot("Step6-sayfadaurunler") is False: return False
        if self.hover("//a[@id='nav-link-accountList']", "a#nav-link-accountList") is False: return False
        if self.goToWhiteList() is False: return False
        if self.screenshot("Step7-listeekrani") is False: return False
        if self.findProductWL() is False: return False
        if self.deleteProduct() is False: return False
        if self.screenshot("Step8-urunusil") is False: return False
        if self.findProductWL() is False: return False

    def start(self):
        if os.name == "nt":
            path = os.getcwd() + os.sep + "drivers"
            os.chdir(path)

        if self.driver is "Chrome":
            try:
                self._browser = selenium.webdriver.Chrome()
            except selenium.common.exceptions.WebDriverException:
                msg = "Başlangıç problemi"
                self.log("Başlangıç Problemi =>", msg)
                return False
        else:
            try:
                self._browser = selenium.webdriver.Firefox()
            except selenium.common.exceptions.WebDriverException:
                msg = "Başlangıç problemi"
                self.log("Başlangıç Problemi =>", msg)
                return False
        try:
            WebDriverWait(self._browser, 5).until(EC.presence_of_element_located((By.TAG_NAME, 'body')))
            return True
        except TimeoutException:
            self.log("Sayfa Yüklemesi =>", " Sayfanın yüklenmesi 10 saniyeden uzunsürüyor")
            return False

    def __del__(self):
        if self.suchWindow() is True:
            command = 'alert("Sonlandi")'
            print("Sonlandi")
            self._browser.close()



    # Log & Exceptions Methods
    def log(self, type, message):
       msg = type + "\t" + message + "\t" + str(datetime.datetime.now()) + "\n"
       self.__logfile.write(msg)

    def suchExceptions(self, xpath):
        msg = xpath + " elemanı bulunamadı "
        if self.suchWindow() is True:
            try:
                self._browser.find_element_by_xpath(xpath)
                return True
            except selenium.common.exceptions.NoSuchElementException:
                self.log("No Such Element => ", msg)
                return False
        else:
            return False

    def notVisible(self, xpath):
        msg = xpath + " elemanı sayfada görüntülenmiyor"
        if self.suchWindow() is True:
            try:
                element = self._browser.find_element(By.XPATH, xpath)
                if element.is_displayed():
                    return True
                else:
                    self.log("Not Visible Element =>", msg)
                    return False
            except selenium.common.exceptions.ElementNotVisibleException:
                self.log("Not Visible Element =>", msg)
                return False
        else:
            return False

    def timeout_load(self, time, xpath):
        msg = xpath + " elemanının yüklenmesi " + str(time) + " saniyeden uzun sürdü"
        if self.suchWindow() is True:
            try:
                WebDriverWait(self._browser, time).until(EC.presence_of_element_located((By.XPATH, xpath)))
                return True
            except selenium.common.exceptions.TimeoutException:
                self.log("Time Out => ", msg)
                return False
        else:
            return False

    def clickable_load(self, time, xpath):
        msg = xpath + " elemanı " + str(time) + " saniye sonra tıklanabilir değil"
        if self.suchWindow() is True:
            try:
                WebDriverWait(self._browser, time).until(EC.element_to_be_clickable((By.XPATH, xpath)))
                return True
            except selenium.common.exceptions.TimeoutException:
                self.log("Time Out Clickable =>", msg)
        else:
            return False

    def suchWindow(self):
        try:
            self.titleNow = self._browser.find_element_by_xpath("//body")
        except selenium.common.exceptions.NoSuchWindowException:
            msg = "Pencereye erişilemiyor"
            self.log("Pencere Erişimi => ", msg)
            self._browser.close()
            return False
        except selenium.common.exceptions.WebDriverException:
            msg = "Pencereye erişilemiyor"
            self.log("Pencere Erişimi => ", msg)
            self._browser.close()
            return False
        except selenium.common.exceptions.NoSuchFrameException:
            msg = "Pencereye erişilemiyor"
            self.log("Pencere Erişimi => ", msg)
            self._browser.close()
            return False

        return True

    def interacteble(self, xpath):
        if self.suchWindow() is True:
            try:
                self._browser.find_element_by_xpath(xpath)
            except selenium.common.exceptions.ElementNotInteractableException:
                return False
        else:
            return False

    #############################################
    def elem_border(self, query):
        if self.suchWindow() is True:
            script = "document.querySelector('" + query + "').style.border='1px solid RED'"
            self._browser.execute_script(script)
        else:
            return False

    def screenshot(self, filename):
        if self.suchWindow() is True:
            filename = "../screenshots/step_" + str(filename) + ".png"
            time.sleep(2)
            try:
                self._browser.save_screenshot(filename)
            except selenium.common.exceptions.WebDriverException:
                self.log("Ekran Goruntusu =>","Ekran Görüntüsü kaydedilemedi")
                return False
            return True
        else:
            self.log("Ekran Görüntüsü =>","Ekran Görüntüsü Kaydedilemedi")
            return False


    def hover(self, xpath, js_query):
        if self.suchWindow() is True:
            if self.notVisible(xpath) is True:
                if self.notVisible(xpath) is not False:
                    self._browser.find_element_by_xpath(xpath).location_once_scrolled_into_view
                    hover = ActionChains(self._browser).move_to_element(self._browser.find_element_by_xpath(xpath))
                    self.elem_border(js_query)
                    hover.perform()
                    return True
                else:
                    return False
        return False

    def click(self, xpath, js_query):
        if self.suchWindow() is True and self.clickable_load(5, xpath) is True and self.suchExceptions(xpath) is True:
            self.elem_border(js_query)
            self._browser.find_element_by_xpath(xpath).click()
        else:
            return False

    def login(self, inputmail, inputpass, logintry):
        if self.suchWindow() is True and logintry > 5:
            self.log("Login => ", "Login formu en az 5 kere denendi ancak başarılı olamadı")
            return False

        inputmailOK = inputmail
        inputpassOK = inputpass
        if self.timeout_load(10, "//body") is True:
            if inputmail == 0 and inputpass == 0:
                try:
                    assert 'Sign' in self._browser.title
                    self.log("Login Hatası =>", "Login işlemi sonrasında sayfa title Sign içeriyor..")
                    return False
                except AssertionError:
                    return self.isLogin()

            if self.suchExceptions("//form[@name='signIn']"):
                self.elem_border("form")

                if inputmail == 1 and self.suchExceptions("//input[@name='email']") is True:
                    if self.timeout_load(5, "//input[@name='email']") is True and self._browser.find_element_by_xpath(
                            "//input[@name='email']").is_displayed() is True:
                        self._browser.find_element_by_xpath("//input[@name='email']").send_keys(self.__email)
                        inputmailOK = 0

                if inputpass == 1 and self.suchExceptions(
                        "//input[@name='password']") is True and self._browser.find_element_by_xpath(
                    "//input[@name='password']").is_displayed() is True:
                    if self.timeout_load(5, "//input[@name='password']") is True:
                        self._browser.find_element_by_xpath("//input[@name='password']").send_keys(self.__password)
                        inputpassOK = 0

                if self.clickable_load(3, "//input[@type='submit']") is True:
                    self._browser.find_element_by_xpath("//input[@type='submit']").click()
                    return self.login(inputmailOK, inputpassOK, (logintry + 1))
                else:
                    return False

                # clicksubmit
                #
        else:
            return False

    def isLogin(self):
        if self.suchWindow() is True and self.timeout_load(5, "//body") and self.suchExceptions(
                "//a[@id='nav-recently-viewed']"):
            if self.notVisible("//a[@id='nav-recently-viewed']") is True:
                self.log("Login =>", "Login işlemi başarılı")
                return True
            else:
                self.log("Login =>", "Login için kullanılan nav-recently-viewed bulunamadı")
                return False
        else:
            self.log("Login =>", "Login için kullanılan a#nav-recently-viewed elemnti visible olmadı")
            return False

    def searchItem(self, item, times):
        if self.suchWindow() is True:
            if times > 5:
                self.log("Search => ", "Arama 5 kereden fazla denendi ve başarısız oldu")
                return False

            if self.timeout_load(5, "//body") is True and self.suchExceptions("//input[@id='twotabsearchtextbox']"):
                self._browser.find_element_by_xpath("//input[@id='twotabsearchtextbox']").send_keys(item)
            else:
                self.log("Search => ", "Arama alanı bulunamadı")
                return False

            if self.suchExceptions("//div[@class='nav-search-submit nav-sprite']") is True and self.clickable_load(3,
                                                                                                                   "//div[@class='nav-search-submit nav-sprite']") is True:
                self._browser.find_element_by_xpath("//div[@class='nav-search-submit nav-sprite']").click()
                return True
            else:
                self.log("Search => ", "Arama butonu bulunamadı")
                return False
        else:
            return False

    def results(self):
        if self.suchWindow() is True:
            if self.timeout_load(5, "//body") is True:
                if self.suchExceptions("//div[@id='s-result-info-bar-content']/div/div"):
                    result = self._browser.find_element_by_xpath("//div[@id='s-result-info-bar-content']/div/div").text
                    self.log("Arama =>", "Arama Yapıldı")
                    self.log("Arama Sonucu =>", result)
                else:
                    self.log("Arama Sonucu =>", "Arama sonuçları tespit edilemedi")
                    return False
            else:
                self.log("Sayfa =>", "Sayfa çok geç yükleniyor")
                return False
        else:
            return False

    def scroll(self, xpath):
        if self.suchWindow() is True:
            if self.suchExceptions(xpath) is True:
                time.sleep(3)
                self._browser.find_element_by_xpath(xpath).location_once_scrolled_into_view
                return True
            else:
                msg = xpath + " elementi için scroll kullanılamadı"
                self.log("Scroll =>", msg)
                return False
        else:
            return False

    def changePage(self, page):
        if self.suchWindow() is True:
            if self.suchExceptions("//div[@id='bottomBar']"):
                pageList = self._browser.find_elements_by_xpath("//div[@id='bottomBar']/div/span")
                if len(pageList) > 0:
                    for pageN in pageList:
                        if pageN.text == page or pageN.text == str(page):
                            pageN.click()
                            msg = str(page) + ". sayfa tıklandı"
                            self.log("Sayfalama =>", msg)
                            return True

                    self.log("Sayfalama =>", "Sayfa listesi bulundu ancak istediğiniz sayfa linki bulunamadı")
                    return False
                else:
                    self.log("Sayfalama =>", "Sayfalar listesi bulunamadı 2")
                    return False
            else:
                self.log("Sayfalama =>", "Sayfalar listesi bulunamadı")
                return False
        else:
            return False

    def pageControl(self, page):
        if self.suchWindow() is True and self.timeout_load(15, "//body") is True and self.timeout_load(15,
                                                                                                       "//div[@id='bottomBar']") is True:
            if self.scroll("//div[@id='bottomBar']") is True:
                if self.suchExceptions("//div[@id='bottomBar']"):
                    pageList = self._browser.find_elements_by_xpath("//div[@id='bottomBar']/div/span")
                    if len(pageList) > 0:
                        if self.suchExceptions("//span[@class='pagnCur']") is True:
                            for pageN in pageList:
                                if pageN.text == page or pageN.text == str(page):
                                    if str(pageN.get_attribute('class')) == "pagnCur":
                                        msg = str(page) + ". sayfadasınız"
                                        self.log("Sayfalama =>", msg)
                                        return True

                            msg = "Sayfa listesi bulundu ancak " + str(page) + ". sayfada olduğunuz onaylanamadı"
                            self.log("Sayfalama =>", msg)
                            return False

                    else:
                        self.log("Sayfalama => ", "Sayfalama listesi bulunamadı")



                else:
                    self.log("Sayfa Kontrol =>", "Sayfa kontrolü için sayfa numaraları alanı bulunamadı")
                    return True
            else:
                return False
        else:
            return False

    def productsOnpage(self, target, parent_xpath, child_xpath):
        if self.suchWindow() is True and self.timeout_load(10, "//body") is True and self.timeout_load(10,
                                                                                                       parent_xpath):
            key = target if target == 0 else target - 1
            numbOfProducts = len(self._browser.find_elements_by_xpath(child_xpath))
            if numbOfProducts >= target:
                print(self._browser.find_elements_by_xpath(child_xpath)[key])
                self.TargetProduct = self._browser.find_elements_by_xpath(child_xpath)[key]
                self.TargetProductASIN = self.TargetProduct.get_attribute('data-asin')
                self.TargetProduct.location_once_scrolled_into_view

                msg = "Hedef ürün bulundu. ASIN : " + self.TargetProduct.get_attribute('data-asin')
                self.log("Ürün =>", msg)
                self.openAndAdd()
                return True
            else:
                if numbOfProducts == 0:
                    self.log("Ürün => ", "Ürünler bulunamadı")
                else:
                    self.log("Ürün =>", "Yeterli Sayıda Ürün bulunamadı")

                return False

        else:
            return False

    def openAndAdd(self):
        if self.suchWindow() is True and self.timeout_load(10, "//body") is True:
            self.TargetProduct.find_element_by_tag_name("a").click()
            if self.suchExceptions("//input[@id='add-to-wishlist-button-submit']") is True:
                button = self._browser.find_element_by_xpath("//input[@id='add-to-wishlist-button-submit']")
                button.location_once_scrolled_into_view
                button.click()

                time.sleep(3)  # wait new javascript element

                if self.timeout_load(5, "//body") is True:
                    if self.suchExceptions("//button[@data-action='a-popover-close']") is False:
                        if self.suchExceptions("//label[@for='WLNEW_list_type_WL']") is True:
                            if self.clickable_load(3, "//label[@for='WLNEW_list_type_WL']") is True:
                                time.sleep(3)
                                self._browser.find_element_by_xpath("//label[@for='WLNEW_list_type_WL']").click()
                                self._browser.find_element_by_xpath('//span[@data-action="reg-create-submit"]').click()
                                self.log("Add to List =>", "Hedef ürün Listeye eklendi")
                                time.sleep(3)
                                # a-popover-close
                                self.screenshot()
                                if self.suchExceptions("//button[@data-action='a-popover-close']") is True:
                                    self._browser.find_element_by_xpath(
                                        "//button[@data-action='a-popover-close']").click()
                                    time.sleep(2)
                                    return True
                                else:
                                    self.log("Add to List =>", "Ekleme sonrası açılan popup kapatılamadı")
                                    return False
                            else:
                                self.log("Add to List =>", "Popup sonrası Listeye Seçimi aktif olmuyor")
                                return False
                        else:
                            self.log("Add to List =>", "List seçeneği 3 saniyeden fazla bir süredir tıklanabilir değil")
                    else:
                        self._browser.find_element_by_xpath("//button[@data-action='a-popover-close']").click()
                        time.sleep(2)
                        return True
                else:
                    self.log("Add to List =>", "Add to List popup 5 saniyeden fazla bir süredir yüklenmedi")
                    return False
            else:

                return False
        else:
            return False

    def goToWhiteList(self):
        if self.suchWindow() is True:
            if self.suchExceptions("//div[@id='nav-flyout-wl-items']") is True:
                time.sleep(2)
                if len(self._browser.find_elements_by_xpath("//div[@id='nav-flyout-wl-items']/div/a")) > 0:
                    self._browser.find_elements_by_xpath("//div[@id='nav-flyout-wl-items']/div/a")[0].click()
                    return True
                else:
                    self.log("Open List =>", " List link bulunamadı")
                    return False
            else:
                self.log("Open List =>", " List link bulunamadı")
                return False
        else:
            return False

    def findProductWL(self):
        time.sleep(3)
        if self.timeout_load(10, "//body") is True:
            if self.suchExceptions("//div[@id='g-items']") is True:
                self._browser.find_element_by_xpath("//div[@id='item-page-wrapper']").location_once_scrolled_into_view
                time.sleep(3)
                list = self._browser.find_elements_by_css_selector("div.a-section.a-spacing-none.g-item-sortable")
                for k in list:
                    data_params = str(k.get_attribute('data-reposition-action-params'))
                    data_class = str(k.get_attribute('class'))
                    if data_params.find(self.TargetProductASIN) > 0 and data_class.find('g-item-sortable-removed') < 0:
                        self.log("List => ", "Listeye eklenen hedef ürün listede bulundu")
                        return True

                self.log("List =>", "List içerisinde ürün bulunamadı")
                return True
            else:
                self.log(" List => ", "List içerisinde ürün bulunamadı")
                return False
        else:
            self.log(" List =>", "Sayfanın yüklenmesi 10 saniyeden fazla sürdü")
            return False

    def deleteProduct(self):
        if self.suchWindow() is True:
            time.sleep(3)
            if self.timeout_load(10, "//body") is True:
                if self.suchExceptions("//span[@data-action='reg-item-delete']") is True:
                    list = self._browser.find_elements_by_xpath("//span[@data-action='reg-item-delete']")
                    if len(list) > 0:
                        for buton in list:
                            data_params = str(buton.get_attribute('data-reg-item-delete'))
                            print(data_params)
                            if data_params.find(self.TargetProductASIN) > 0:
                                buton.location_once_scrolled_into_view
                                buton.find_element_by_xpath("//input[@name='submit.deleteItem']").click()
                                self.log("Listeden Silme =>", "Ürün silme linki tıklandı")
                                time.sleep(5)
                                return True

                        self.log("Listeden Silme =>", "Ürün silme linki bulunamadı")
                        return False
                    else:
                        self.log("listeden Silme =>", "Ürünü kaldırmak için buton bulunamadı")
                        return False
                else:
                    self.log("Listeden Silme => ", "Buton Bulunamadı")
                    return False
            else:
                self.log("Listeden Silme =>", "Sayfanın yüklenmesi 10 saniyeden daha uzun sürdü")
                return False
        else:
            return False


testet = minitest_tool()
